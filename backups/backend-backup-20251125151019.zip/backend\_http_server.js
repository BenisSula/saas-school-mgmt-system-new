// Auto-generated file for Node built-in '_http_server'
// This prevents Jest ENOENT errors when Jest tries to resolve built-ins as file paths
// Simply re-exports the actual Node.js built-in module
module.exports = require('_http_server');
