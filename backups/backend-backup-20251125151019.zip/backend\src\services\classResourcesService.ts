/**
 * Class Resources Service (Legacy)
 * 
 * DEPRECATED: This file is kept for backward compatibility.
 * All functionality has been moved to unifiedClassResourcesService.
 * 
 * This file re-exports from the unified service to maintain compatibility
 * with existing routes (teachers.ts, students.ts).
 */

// Re-export from unified service with backward-compatible types
import type { PoolClient } from 'pg';
import {
  uploadClassResource as unifiedUploadClassResource,
  getClassResources as unifiedGetClassResources,
  deleteClassResource as unifiedDeleteClassResource,
  type UnifiedClassResource,
  type UploadClassResourceInput,
} from './classResources/unifiedClassResourcesService';

// Legacy interfaces for backward compatibility
export interface ClassResourceInput {
  classId: string;
  title: string;
  description?: string;
  file: {
    filename: string;
    mimetype: string;
    size: number;
    data: Buffer;
  };
}

export interface ClassResource {
  id: string;
  tenant_id: string;
  teacher_id: string;
  class_id: string;
  title: string;
  description: string | null;
  file_url: string;
  file_type: string;
  size: number;
  created_at: Date;
}

/**
 * Upload a class resource (teacher-scoped)
 * Wrapper around unified service for backward compatibility
 */
export async function uploadClassResource(
  client: PoolClient,
  schema: string,
  tenantId: string,
  teacherId: string,
  input: ClassResourceInput,
  actorId: string
): Promise<ClassResource> {
  const unified = await unifiedUploadClassResource(
    client,
    schema,
    tenantId,
    teacherId,
    input,
    actorId
  );

  // Map unified format to legacy format
  return {
    id: unified.id,
    tenant_id: unified.tenant_id || tenantId,
    teacher_id: unified.teacher_id || teacherId,
    class_id: unified.class_id,
    title: unified.title,
    description: unified.description,
    file_url: unified.resource_url,
    file_type: unified.mime_type || 'application/octet-stream',
    size: unified.file_size || 0,
    created_at: unified.created_at,
  };
}

/**
 * Get class resources (teacher or student-scoped)
 * Wrapper around unified service for backward compatibility
 */
export async function getClassResources(
  client: PoolClient,
  schema: string,
  classId: string,
  teacherId?: string
): Promise<ClassResource[]> {
  const unified = await unifiedGetClassResources(client, schema, classId, teacherId);

  // Map unified format to legacy format
  return unified.map((u) => ({
    id: u.id,
    tenant_id: u.tenant_id || '',
    teacher_id: u.teacher_id || '',
    class_id: u.class_id,
    title: u.title,
    description: u.description,
    file_url: u.resource_url,
    file_type: u.mime_type || 'application/octet-stream',
    size: u.file_size || 0,
    created_at: u.created_at,
  }));
}

/**
 * Delete a class resource (teacher-scoped)
 * Wrapper around unified service for backward compatibility
 */
export async function deleteClassResource(
  client: PoolClient,
  schema: string,
  teacherId: string,
  resourceId: string,
  actorId: string
): Promise<boolean> {
  return unifiedDeleteClassResource(client, schema, resourceId, actorId, teacherId);
}
