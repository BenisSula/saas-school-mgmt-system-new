/**
 * Prometheus Metrics Endpoint
 */

import { Router, type Request, type Response } from 'express';
import { getMetrics, getMetricsContentType } from '../middleware/metrics';

const router = Router();

// Prometheus metrics endpoint
router.get('/', async (_req: Request, res: Response) => {
  try {
    res.set('Content-Type', getMetricsContentType());
    res.end(await getMetrics());
  } catch {
    res.status(500).json({ error: 'Failed to generate metrics' });
  }
});

// Frontend performance metrics endpoint
router.post('/frontend', async (req: Request, res: Response) => {
  try {
    // Check if body exists and is parsed
    if (!req.body) {
      return res.status(400).json({ error: 'Request body is missing' });
    }

    const { metrics } = req.body;

    if (!metrics) {
      return res.status(400).json({ error: 'Metrics field is missing' });
    }

    if (!Array.isArray(metrics)) {
      return res.status(400).json({ error: 'Invalid metrics format: expected array' });
    }

    // Log frontend metrics (can be extended to store in database or send to monitoring service)
    // Only log in development to avoid console spam
    if (process.env.NODE_ENV === 'development') {
      console.log('[Frontend Metrics] Received', metrics.length, 'metrics');
    }

    // TODO: Store metrics in database or send to monitoring service
    // For now, just acknowledge receipt

    res.json({ success: true, received: metrics.length });
  } catch (error) {
    // Silently handle errors - don't break the app if metrics fail
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    if (process.env.NODE_ENV === 'development') {
      console.error('[Frontend Metrics] Error:', errorMessage);
    }
    // Return 200 to prevent frontend from retrying
    res.status(200).json({ 
      success: false,
      error: 'Failed to process metrics',
      details: process.env.NODE_ENV === 'development' ? errorMessage : undefined
    });
  }
});

export default router;
