import { Pool, PoolClient } from 'pg';
import fs from 'fs';
import path from 'path';
import { getPool } from './connection';
import crypto from 'crypto';

export function assertValidSchemaName(schemaName: string): void {
  if (!/^[a-zA-Z0-9_]+$/.test(schemaName)) {
    throw new Error('Invalid schema name');
  }
}

export function createSchemaSlug(name: string): string {
  return `tenant_${name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')}`;
}

interface TenantInput {
  name: string;
  domain?: string;
  schemaName: string;
  subscriptionType?: 'free' | 'trial' | 'paid';
  status?: 'active' | 'suspended' | 'deleted';
  billingEmail?: string | null;
}

export async function createTenantRecord(
  pool: Pool,
  { name, domain, schemaName, subscriptionType, status, billingEmail }: TenantInput
): Promise<{ id: string }> {
  const id = crypto.randomUUID();
  const result = await pool.query(
    `
      INSERT INTO shared.tenants (id, name, domain, schema_name, subscription_type, status, billing_email)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING id
    `,
    [
      id,
      name,
      domain ?? null,
      schemaName,
      subscriptionType ?? 'trial',
      status ?? 'active',
      billingEmail ?? null,
    ]
  );

  return { id: result.rows[0].id };
}

export async function createTenantSchema(pool: Pool, schemaName: string): Promise<void> {
  assertValidSchemaName(schemaName);
  await pool.query(`CREATE SCHEMA IF NOT EXISTS ${schemaName}`);
}

export async function runTenantMigrations(pool: Pool, schemaName: string): Promise<void> {
  const migrationsDir = path.resolve(__dirname, 'migrations', 'tenants');
  let files: string[] = [];
  try {
    files = (await fs.promises.readdir(migrationsDir))
      .filter((file) => file.endsWith('.sql'))
      .sort();
  } catch (error: unknown) {
    if (
      typeof error === 'object' &&
      error !== null &&
      'code' in error &&
      (error as { code?: string }).code === 'ENOENT'
    ) {
      return;
    }
    throw error;
  }

  const client = await pool.connect();
  try {
    assertValidSchemaName(schemaName);
    await client.query(`SET search_path TO ${schemaName}, public`);
    for (const file of files) {
      const sql = await fs.promises.readFile(path.join(migrationsDir, file), 'utf-8');
      const renderedSql = sql.replace(/{{schema}}/g, schemaName);

      // Split SQL statements properly, handling:
      // - Comments (-- style)
      // - String literals (single quotes)
      // - Dollar-quoted strings ($$ ... $$ or $tag$ ... $tag$)
      // - Parentheses (for CHECK constraints, function calls, etc.)
      // - Semicolons that are actual statement terminators
      const statements: string[] = [];
      let currentStatement = '';
      let inString = false;
      let inComment = false;
      let inDollarQuote = false;
      let dollarQuoteTag = '';
      let parenDepth = 0;

      for (let i = 0; i < renderedSql.length; i++) {
        const char = renderedSql[i];
        const nextChar = renderedSql[i + 1] || '';
        const prevChar = renderedSql[i - 1] || '';

        // Handle dollar-quoted strings ($$ ... $$ or $tag$ ... $tag$)
        if (!inString && !inComment && char === '$') {
          if (!inDollarQuote) {
            // Check if this is the start of a dollar quote
            // For $$, nextChar should be $, for $tag$, we need to find the matching $
            if (nextChar === '$') {
              // Simple $$ case - make sure we're not in the middle of a word
              // Check if previous char is whitespace or we're at start of statement
              const prevIsValid = i === 0 || /\s/.test(prevChar);
              if (prevIsValid) {
                inDollarQuote = true;
                dollarQuoteTag = '';
                currentStatement += '$$';
                i++; // Skip the second $
                continue;
              }
            } else {
              // Look for $tag$ pattern
              let j = i + 1;
              let tag = '';
              while (j < renderedSql.length && renderedSql[j] !== '$') {
                tag += renderedSql[j];
                j++;
              }
              if (j < renderedSql.length && renderedSql[j] === '$') {
                // Found opening dollar quote $tag$
                inDollarQuote = true;
                dollarQuoteTag = tag;
                currentStatement += char + tag + '$';
                i = j; // Skip to after the closing $
                continue;
              }
            }
          } else {
            // We're inside a dollar quote, check if this is the closing tag
            if (dollarQuoteTag === '') {
              // Simple $$ case - check if next char is $
              if (nextChar === '$') {
                // Found closing $$
                inDollarQuote = false;
                currentStatement += '$$';
                i++; // Skip the second $
                dollarQuoteTag = '';
                continue;
              }
            } else {
              // $tag$ case - build the potential closing tag
              let j = i + 1;
              let potentialTag = '';
              while (j < renderedSql.length && renderedSql[j] !== '$') {
                potentialTag += renderedSql[j];
                j++;
              }
              if (j < renderedSql.length && renderedSql[j] === '$' && potentialTag === dollarQuoteTag) {
                // Found closing dollar quote
                inDollarQuote = false;
                currentStatement += char + potentialTag + '$';
                i = j; // Skip to after the closing $
                dollarQuoteTag = '';
                continue;
              }
            }
          }
        }

        // If we're inside a dollar quote, just accumulate characters
        if (inDollarQuote) {
          currentStatement += char;
          continue;
        }

        // Handle comments
        if (!inString && char === '-' && nextChar === '-') {
          inComment = true;
          currentStatement += char;
          continue;
        }

        if (inComment) {
          currentStatement += char;
          if (char === '\n' || char === '\r') {
            inComment = false;
          }
          continue;
        }

        // Handle string literals
        if (char === "'" && prevChar !== '\\') {
          inString = !inString;
          currentStatement += char;
          continue;
        }

        if (inString) {
          currentStatement += char;
          continue;
        }

        // Track parentheses depth
        if (char === '(') {
          parenDepth++;
          currentStatement += char;
          continue;
        }

        if (char === ')') {
          parenDepth--;
          currentStatement += char;
          continue;
        }

        // Only split on semicolon if we're not in a string, comment, dollar quote, or nested parentheses
        if (char === ';' && parenDepth === 0 && !inString && !inComment && !inDollarQuote) {
          currentStatement += char;
          const trimmed = currentStatement.trim();
          // Remove comments and check if there's actual SQL content
          // Keep comments that are part of the statement (for documentation)
          const cleaned = trimmed
            .split('\n')
            .map(line => {
              const commentIndex = line.indexOf('--');
              if (commentIndex >= 0) {
                // Check if -- is inside a string (shouldn't happen at this point, but be safe)
                return line.substring(0, commentIndex).trim();
              }
              return line.trim();
            })
            .filter(line => line.length > 0)
            .join('\n')
            .trim();
          
          // Only add statement if it has actual SQL content (not just comments)
          if (cleaned.length > 0 && !cleaned.match(/^\s*$/)) {
            statements.push(trimmed);
          }
          currentStatement = '';
          continue;
        }

        currentStatement += char;
      }

      // Add any remaining statement (shouldn't happen with proper SQL, but handle it)
      if (currentStatement.trim()) {
        const trimmed = currentStatement.trim();
        // Remove comments and check if there's actual SQL content
        const cleaned = trimmed
          .split('\n')
          .map(line => {
            const commentIndex = line.indexOf('--');
            if (commentIndex >= 0) {
              return line.substring(0, commentIndex).trim();
            }
            return line.trim();
          })
          .filter(line => line.length > 0)
          .join('\n')
          .trim();
        
        if (cleaned.length > 0 && !cleaned.match(/^\s*$/)) {
          statements.push(trimmed);
        }
      }

      for (let idx = 0; idx < statements.length; idx++) {
        let statement = statements[idx];
        if (statement.trim()) {
          try {
            // Clean up the statement: remove leading comments-only lines, but keep comments within the statement
            const lines = statement.split('\n');
            let startIndex = 0;
            // Skip leading comment-only lines
            for (let i = 0; i < lines.length; i++) {
              const line = lines[i].trim();
              if (line.length === 0 || line.startsWith('--')) {
                startIndex = i + 1;
              } else {
                break;
              }
            }
            // Reconstruct statement without leading comment-only lines
            if (startIndex > 0) {
              statement = lines.slice(startIndex).join('\n');
            }
            
            const cleanedStatement = statement.trim();
            
            // Only execute if there's actual SQL content (not just comments)
            if (cleanedStatement.length > 0 && !cleanedStatement.match(/^[\s-]*$/)) {
              await client.query(cleanedStatement);
            }
          } catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            console.error(
              `[Migration Error] Failed to execute statement ${idx + 1}/${statements.length} in file ${file}:`
            );
            console.error(
              `[Migration Error] Statement: ${statement.substring(0, 400)}${statement.length > 400 ? '...' : ''}`
            );
            console.error(`[Migration Error] Error: ${errorMsg}`);
            // Show more context for debugging
            if (statement.includes('DO $$') || statement.includes('DECLARE')) {
              console.error(`[Migration Error] This statement contains a DO block. Full statement length: ${statement.length}`);
              // Show the DO block part
              const doIndex = statement.indexOf('DO $$');
              if (doIndex >= 0) {
                console.error(`[Migration Error] DO block starts at position ${doIndex}`);
                console.error(`[Migration Error] DO block context: ${statement.substring(Math.max(0, doIndex - 50), doIndex + 100)}`);
              }
            }
            throw new Error(
              `Migration failed in ${file} at statement ${idx + 1}: ${errorMsg}\nStatement: ${statement.substring(0, 300)}...`
            );
          }
        }
      }
    }
  } finally {
    await client.query('SET search_path TO public');
    client.release();
  }
}

export async function seedTenant(pool: Pool, schemaName: string): Promise<void> {
  const client = await pool.connect();
  try {
    assertValidSchemaName(schemaName);
    await client.query(
      `
        INSERT INTO ${schemaName}.branding_settings (id, logo_url, primary_color, secondary_color, theme_flags)
        VALUES (uuid_generate_v4(), NULL, '#1d4ed8', '#0f172a', '{}'::jsonb)
        ON CONFLICT (id) DO NOTHING
      `
    );
    await client.query(
      `
        INSERT INTO ${schemaName}.grade_scales (id, min_score, max_score, grade, remark)
        VALUES
          (uuid_generate_v4(), 90, 100, 'A+', 'Outstanding'),
          (uuid_generate_v4(), 80, 89.99, 'A', 'Excellent'),
          (uuid_generate_v4(), 70, 79.99, 'B', 'Very Good'),
          (uuid_generate_v4(), 60, 69.99, 'C', 'Good'),
          (uuid_generate_v4(), 50, 59.99, 'D', 'Satisfactory'),
          (uuid_generate_v4(), 0, 49.99, 'F', 'Needs Improvement')
        ON CONFLICT (grade) DO NOTHING
      `
    );
  } finally {
    client.release();
  }
}

export async function createTenant(input: TenantInput, poolParam?: Pool): Promise<{ id: string }> {
  const pool = poolParam ?? getPool();

  await createTenantSchema(pool, input.schemaName);
  await runTenantMigrations(pool, input.schemaName);
  await seedTenant(pool, input.schemaName);
  const tenant = await createTenantRecord(pool, input);

  return tenant;
}

export async function withTenantSearchPath<T>(
  pool: Pool,
  schemaName: string,
  fn: (client: PoolClient) => Promise<T>
): Promise<T> {
  const client = await pool.connect();
  try {
    assertValidSchemaName(schemaName);
    await client.query(`SET search_path TO ${schemaName}, public`);
    return await fn(client);
  } finally {
    await client.query('SET search_path TO public');
    client.release();
  }
}
